# pacviz
![R-CMD-check](https://github.com/PharaohCola13/pacviz/workflows/R-CMD-check/badge.svg)   [![DOI](https://zenodo.org/badge/222631928.svg)](https://zenodo.org/badge/latestdoi/222631928)

<img src='https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/Pacman.svg/972px-Pacman.svg.png' width='100'/>

Pac-Man data visualization for R
